# XML100 overall results

Success is reported before conditional quality metrics.

| Model | Architecture | Aug success | Aug mean Gap % | Aug P95 Gap % | No-aug success | No-aug mean Gap % | Mean vehicles | Inference s/instance | Postprocess s/instance |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| pomo_direct_n100 | pomo | 10000/10000 | 5.9039 | 15.9147 | 10000/10000 | 11.0783 | 12.422 | 0.007927 | 0.002287 |
| pomo_split_v4_n100 | pomo_split | 10000/10000 | 10.1670 | 17.9726 | 10000/10000 | 13.6501 | 12.711 | 0.005035 | 0.037234 |
