#!/usr/bin/env bash
set -Eeuo pipefail

B=/root/autodl-tmp/am_tw_split_v4_n100_eval_20260922
BASE=/root/autodl-tmp/split_v4_n100_eval_20260922
REPO=/root/autodl-tmp/NCOrethinking_directctx_nomask_v4_20260921
PY=/root/miniconda3/bin/python
DIRECT="$B/models/am_tw_direct_n100/epoch-100.pt"
SPLIT=/root/autodl-tmp/am_tw_split_n100_directctx_nomask_v4_20260921/outputs/am_split_tw_100/am_tw_split_n100_directctx_nomask_v4_20260921T173646/epoch-100.pt

mkdir -p "$B"/{logs,status,pids,results/xml100,results/generalization}
echo crossconstraint_running > "$B/status/phase"
date -u +%FT%TZ > "$B/status/crossconstraint.started_at_utc"

finish() {
  rc=$?
  printf '%s\n' "$rc" > "$B/status/crossconstraint.exit_code"
  date -u +%FT%TZ > "$B/status/crossconstraint.finished_at_utc"
  if [[ "$rc" -eq 0 ]]; then
    echo evaluation_completed > "$B/status/phase"
  else
    echo crossconstraint_failed > "$B/status/phase"
  fi
}
trap finish EXIT

run_stage() {
  name=$1
  shift
  echo "[$(date -u +%FT%TZ)] START $name"
  "$@"
  rc=$?
  printf '%s\n' "$rc" > "$B/status/${name}.exit_code"
  echo "[$(date -u +%FT%TZ)] END $name exit=$rc"
  return "$rc"
}

if [[ ! -d "$BASE/data/xml100/XML/instances" ]]; then
  /root/miniconda3/bin/bsdtar -xf "$BASE/data/xml100/XML.7z" -C "$BASE/data/xml100"
fi

run_stage xml100 \
  env PYTHONPATH="$B/xml100" "$PY" "$B/xml100/evaluate_xml100.py" \
  --repo "$REPO" --models "$B/models_xml100_am_tw.json" \
  --data-root "$BASE/data/xml100" \
  --dataset-manifest "$BASE/scripts/xml100/xml100_dataset_manifest.json" \
  --optimal-costs "$BASE/scripts/xml100/xml100_optimal_costs.csv" \
  --output "$B/results/xml100" --device cuda:0 --augmentation 8 --seed 1234 \
  --batch-size-am 64 --require-checkpoint-hashes

run_stage xml100_verify \
  env PYTHONPATH="$B/xml100" "$PY" "$B/xml100/verify_xml100_results.py" \
  --results "$B/results/xml100/xml100_results.csv" \
  --models "$B/models_xml100_am_tw.json" \
  --data-root "$BASE/data/xml100" \
  --dataset-manifest "$BASE/scripts/xml100/xml100_dataset_manifest.json" \
  --optimal-costs "$BASE/scripts/xml100/xml100_optimal_costs.csv" \
  --report "$B/results/xml100/verification_report.json"

run_stage xml100_summarize \
  "$PY" "$B/xml100/summarize_xml100.py" \
  --results "$B/results/xml100/xml100_results.csv" \
  --output-dir "$B/results/xml100/summary"

for size in 200 500 1000; do
  batch=32
  [[ "$size" == 500 ]] && batch=8
  [[ "$size" == 1000 ]] && batch=2

  run_stage "generalization_direct_n${size}" \
    "$PY" "$B/evaluate_size_generalization_am_tw.py" \
    --repo "$REPO" \
    --dataset "$BASE/data/generalization/cvrp${size}_n1000_seed1234_cap50.pt" \
    --checkpoint "$DIRECT" --architecture am_tw \
    --output "$B/results/generalization/am_tw_direct_n100_to_n${size}" \
    --device cuda:0 --batch-size "$batch" --seed 1234

  run_stage "generalization_split_n${size}" \
    "$PY" "$B/evaluate_size_generalization_am_tw.py" \
    --repo "$REPO" \
    --dataset "$BASE/data/generalization/cvrp${size}_n1000_seed1234_cap50.pt" \
    --checkpoint "$SPLIT" --architecture am_split_tw \
    --output "$B/results/generalization/am_tw_split_v4_n100_to_n${size}" \
    --device cuda:0 --batch-size "$batch" --seed 1234
done

echo 0 > "$B/status/crossconstraint_all.exit_code"
