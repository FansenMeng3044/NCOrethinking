#!/usr/bin/env bash
set -Eeuo pipefail

B=/root/autodl-tmp/am_tw_split_v4_n100_eval_20260922
BASE=/root/autodl-tmp/split_v4_n100_eval_20260922
REPO=/root/autodl-tmp/NCOrethinking_directctx_nomask_v4_20260921
PY=/root/miniconda3/bin/python
DIRECT="$B/models/am_tw_direct_n100/epoch-100.pt"
SPLIT=/root/autodl-tmp/am_tw_split_n100_directctx_nomask_v4_20260921/outputs/am_split_tw_100/am_tw_split_n100_directctx_nomask_v4_20260921T173646/epoch-100.pt

mkdir -p "$B"/{logs,status,pids,results/fixed_cvrptw100,results/solomon100}
echo running > "$B/status/phase"
date -u +%FT%TZ > "$B/status/started_at_utc"

finish() {
  rc=$?
  printf '%s\n' "$rc" > "$B/status/fixed_solomon.exit_code"
  date -u +%FT%TZ > "$B/status/fixed_solomon.finished_at_utc"
  if [[ "$rc" -eq 0 ]]; then
    echo fixed_solomon_completed > "$B/status/phase"
  else
    echo fixed_solomon_failed > "$B/status/phase"
  fi
}
trap finish EXIT

run_stage() {
  name=$1
  shift
  echo "[$(date -u +%FT%TZ)] START $name"
  "$@"
  rc=$?
  printf '%s\n' "$rc" > "$B/status/${name}.exit_code"
  echo "[$(date -u +%FT%TZ)] END $name exit=$rc"
  return "$rc"
}

run_stage fixed_cvrptw100_direct \
  "$PY" "$B/evaluate_fixed_tw_am.py" \
  --repo "$REPO" --checkpoint "$DIRECT" \
  --dataset "$BASE/data/fixed/cvrptw100_n10000_seed1234.pt" \
  --architecture am_tw --instances 10000 --batch-size 32 --augmentation 8 \
  --device cuda:0 --seed 1234 --output "$B/results/fixed_cvrptw100/am_tw_direct_n100"

run_stage fixed_cvrptw100_split \
  "$PY" "$B/evaluate_fixed_tw_am.py" \
  --repo "$REPO" --checkpoint "$SPLIT" \
  --dataset "$BASE/data/fixed/cvrptw100_n10000_seed1234.pt" \
  --architecture am_split_tw --instances 10000 --batch-size 32 --augmentation 8 \
  --device cuda:0 --seed 1234 --output "$B/results/fixed_cvrptw100/am_tw_split_v4_n100"

if [[ ! -d "$BASE/data/solomon/solomon_tw_eval_20260827_034100/data/instances_100" ]]; then
  tar --zstd -xf "$BASE/data/solomon/solomon_tw_eval_20260827_034100.tar.zst" \
    -C "$BASE/data/solomon"
fi

run_stage solomon100 \
  "$PY" "$BASE/scripts/solomon/evaluate_solomon.py" \
  --repo "$REPO" --models "$B/models_solomon_am_tw.json" \
  --data-root "$BASE/data/solomon/solomon_tw_eval_20260827_034100/data" \
  --output "$B/results/solomon100" \
  --sintef-bks "$BASE/scripts/solomon/bks_sintef_double_100.csv" \
  --legacy-reference "$BASE/scripts/solomon/reference_academic_legacy.csv" \
  --device cuda:0 --augmentation 8 --coordinate-scale 100 --seed 1234 \
  --protocol mvmoe

run_stage solomon100_verify \
  "$PY" "$BASE/scripts/solomon/verify_solomon_batch.py" \
  --results "$B/results/solomon100/solomon_results.csv" \
  --solutions "$B/results/solomon100/solutions" \
  --data-root "$BASE/data/solomon/solomon_tw_eval_20260827_034100/data" \
  --customers 100 --expected-models 2 \
  --report "$B/results/solomon100/verification_report.json"

run_stage solomon100_summarize \
  "$PY" "$BASE/scripts/solomon/summarize_results.py" \
  --results "$B/results/solomon100/solomon_results.csv" \
  --output "$B/results/solomon100/solomon_summary.csv"

echo 0 > "$B/status/fixed_solomon_all.exit_code"
