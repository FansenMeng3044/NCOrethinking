#!/usr/bin/env python3
"""Validate and summarize the final AM-CVRPTW100 Direct/Split evaluation."""

from __future__ import annotations

import csv
import json
import math
from collections import Counter, defaultdict
from pathlib import Path


ROOT = Path("/root/autodl-tmp/am_tw_split_v4_n100_eval_20260922")
RESULTS = ROOT / "results"


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def require_finite(row: dict[str, str], fields: tuple[str, ...], key: str) -> None:
    for field in fields:
        value = float(row[field])
        if not math.isfinite(value):
            raise ValueError(f"{key}: non-finite {field}")


def paired(left: dict[str, float], right: dict[str, float]) -> tuple[int, int, int]:
    if left.keys() != right.keys():
        raise ValueError("paired key sets differ")
    wins = ties = losses = 0
    for key in left:
        delta = left[key] - right[key]
        if abs(delta) <= 1e-9:
            ties += 1
        elif delta < 0:
            wins += 1
        else:
            losses += 1
    return wins, ties, losses


def mean(values: list[float]) -> float:
    return sum(values) / len(values)


def validate_routes(rows: list[dict[str, str]], root: Path, route_field: str) -> None:
    for row in rows:
        route = root / row[route_field]
        if not route.is_file():
            raise FileNotFoundError(route)


summary_rows: list[dict[str, object]] = []
report_lines = [
    "# AM-Split CVRPTW100 最终评测报告",
    "",
    "所有结果均使用最终 epoch-100 模型。固定 CVRPTW100、Solomon-100 和 XML100 使用 greedy 8-fold；n=200/500/1000 使用 greedy、无增强。所有保存路线均由对应评测器按原问题语义严格复验。",
    "",
    "## 总体结果",
    "",
    "| 评测 | Direct 成功数 | Split 成功数 | Direct 成本 | Split 成本 | Split 相对变化 | Direct 车辆数 | Split 车辆数 | Direct/Split/Tie |",
    "|---|---:|---:|---:|---:|---:|---:|---:|---:|",
]


def add_summary(
    evaluation: str,
    count: int,
    direct_cost: float,
    split_cost: float,
    direct_vehicles: float,
    split_vehicles: float,
    wins: tuple[int, int, int],
    direct_seconds: float,
    split_seconds: float,
) -> None:
    relative = 100.0 * (split_cost / direct_cost - 1.0)
    summary_rows.append(
        {
            "evaluation": evaluation,
            "direct_success": count,
            "split_success": count,
            "direct_mean_cost": direct_cost,
            "split_mean_cost": split_cost,
            "split_relative_change_percent": relative,
            "direct_mean_vehicles": direct_vehicles,
            "split_mean_vehicles": split_vehicles,
            "direct_wins": wins[0],
            "ties": wins[1],
            "split_wins": wins[2],
            "direct_mean_inference_seconds": direct_seconds,
            "split_mean_inference_seconds": split_seconds,
        }
    )
    report_lines.append(
        f"| {evaluation} | {count} | {count} | {direct_cost:.6f} | {split_cost:.6f} | "
        f"{relative:+.3f}% | {direct_vehicles:.3f} | {split_vehicles:.3f} | "
        f"{wins[0]}/{wins[2]}/{wins[1]} |"
    )


# Fixed CVRPTW100.
fixed = RESULTS / "fixed_cvrptw100"
fixed_direct_root = fixed / "am_tw_direct_n100"
fixed_split_root = fixed / "am_tw_split_v4_n100"
fixed_direct = read_csv(fixed_direct_root / "results.csv")
fixed_split = read_csv(fixed_split_root / "results.csv")
for name, rows, root in (
    ("direct", fixed_direct, fixed_direct_root),
    ("split", fixed_split, fixed_split_root),
):
    if len(rows) != 10_000 or len({row["instance"] for row in rows}) != 10_000:
        raise ValueError(f"fixed {name}: row/key count mismatch")
    if Counter(row["status"] for row in rows) != Counter({"ok": 10_000}):
        raise ValueError(f"fixed {name}: non-ok status")
    for row in rows:
        require_finite(row, ("distance", "vehicles"), f"fixed {name}/{row['instance']}")
    validate_routes(rows, root, "routes_json")
fd = {row["instance"]: float(row["distance"]) for row in fixed_direct}
fs = {row["instance"]: float(row["distance"]) for row in fixed_split}
fd_summary = json.loads((fixed_direct_root / "summary.json").read_text())
fs_summary = json.loads((fixed_split_root / "summary.json").read_text())
add_summary(
    "固定 CVRPTW100",
    10_000,
    mean(list(fd.values())),
    mean(list(fs.values())),
    mean([float(row["vehicles"]) for row in fixed_direct]),
    mean([float(row["vehicles"]) for row in fixed_split]),
    paired(fd, fs),
    float(fd_summary["mean_inference_seconds"]),
    float(fs_summary["mean_inference_seconds"]),
)


# Solomon-100.
solomon_root = RESULTS / "solomon100"
solomon = read_csv(solomon_root / "solomon_results.csv")
if len(solomon) != 112 or len({(r["model"], r["instance"]) for r in solomon}) != 112:
    raise ValueError("Solomon row/key count mismatch")
if Counter(r["status"] for r in solomon) != Counter({"ok": 112}):
    raise ValueError("Solomon contains non-ok status")
for row in solomon:
    require_finite(row, ("selected_distance_raw", "selected_vehicles", "elapsed_seconds"), f"Solomon {row['model']}/{row['instance']}")
    route = solomon_root / "solutions" / f"{row['model']}__{row['instance']}__n100.json"
    if not route.is_file():
        raise FileNotFoundError(route)
by_model: dict[str, list[dict[str, str]]] = defaultdict(list)
for row in solomon:
    by_model[row["model"]].append(row)
sd_rows = by_model["am_tw_direct_n100"]
ss_rows = by_model["am_tw_split_v4_n100"]
sd = {r["instance"]: float(r["selected_distance_raw"]) for r in sd_rows}
ss = {r["instance"]: float(r["selected_distance_raw"]) for r in ss_rows}
add_summary(
    "Solomon-100",
    56,
    mean(list(sd.values())),
    mean(list(ss.values())),
    mean([float(r["selected_vehicles"]) for r in sd_rows]),
    mean([float(r["selected_vehicles"]) for r in ss_rows]),
    paired(sd, ss),
    mean([float(r["elapsed_seconds"]) for r in sd_rows]),
    mean([float(r["elapsed_seconds"]) for r in ss_rows]),
)


# XML100.
xml_root = RESULTS / "xml100"
xml_rows = read_csv(xml_root / "xml100_results.csv")
if len(xml_rows) != 20_000 or len({(r["model"], r["instance"]) for r in xml_rows}) != 20_000:
    raise ValueError("XML100 row/key count mismatch")
if Counter(r["status"] for r in xml_rows) != Counter({"ok": 20_000}):
    raise ValueError("XML100 contains non-ok status")
for row in xml_rows:
    require_finite(row, ("cost", "gap_percent", "vehicles", "inference_seconds_amortized"), f"XML100 {row['model']}/{row['instance']}")
validate_routes(xml_rows, xml_root, "routes_json")
xml_by: dict[str, list[dict[str, str]]] = defaultdict(list)
for row in xml_rows:
    xml_by[row["model"]].append(row)
xd_rows = xml_by["am_tw_direct_n100"]
xs_rows = xml_by["am_tw_split_v4_n100"]
xd = {r["instance"]: float(r["cost"]) for r in xd_rows}
xs = {r["instance"]: float(r["cost"]) for r in xs_rows}
add_summary(
    "XML100（CVRPTW→CVRP）",
    10_000,
    mean(list(xd.values())),
    mean(list(xs.values())),
    mean([float(r["vehicles"]) for r in xd_rows]),
    mean([float(r["vehicles"]) for r in xs_rows]),
    paired(xd, xs),
    mean([float(r["inference_seconds_amortized"]) for r in xd_rows]),
    mean([float(r["inference_seconds_amortized"]) for r in xs_rows]),
)


# Cross-constraint and size generalization.
for size in (200, 500, 1000):
    direct_root = RESULTS / "generalization" / f"am_tw_direct_n100_to_n{size}"
    split_root = RESULTS / "generalization" / f"am_tw_split_v4_n100_to_n{size}"
    direct = read_csv(direct_root / "results.csv")
    split = read_csv(split_root / "results.csv")
    for name, rows, root in (("direct", direct, direct_root), ("split", split, split_root)):
        if len(rows) != 1000 or len({r["instance_index"] for r in rows}) != 1000:
            raise ValueError(f"n={size} {name}: row/key count mismatch")
        if Counter(r["status"] for r in rows) != Counter({"ok": 1000}):
            raise ValueError(f"n={size} {name}: non-ok status")
        for row in rows:
            require_finite(row, ("cost", "vehicles", "inference_seconds_amortized"), f"n={size} {name}/{row['instance_index']}")
        validate_routes(rows, root, "route_file")
    gd = {r["instance_index"]: float(r["cost"]) for r in direct}
    gs = {r["instance_index"]: float(r["cost"]) for r in split}
    add_summary(
        f"n={size}（CVRPTW→CVRP）",
        1000,
        mean(list(gd.values())),
        mean(list(gs.values())),
        mean([float(r["vehicles"]) for r in direct]),
        mean([float(r["vehicles"]) for r in split]),
        paired(gd, gs),
        mean([float(r["inference_seconds_amortized"]) for r in direct]),
        mean([float(r["inference_seconds_amortized"]) for r in split]),
    )


report_lines.extend(
    [
        "",
        "## Solomon-100 分组结果",
        "",
        "| 组别 | Direct 距离 | Split 距离 | 相对变化 | Direct 车辆数 | Split 车辆数 |",
        "|---|---:|---:|---:|---:|---:|",
    ]
)
for family in ("C1", "C2", "R1", "R2", "RC1", "RC2"):
    direct_family = [r for r in sd_rows if r["family"] == family]
    split_family = [r for r in ss_rows if r["family"] == family]
    dc = mean([float(r["selected_distance_raw"]) for r in direct_family])
    sc = mean([float(r["selected_distance_raw"]) for r in split_family])
    dv = mean([float(r["selected_vehicles"]) for r in direct_family])
    sv = mean([float(r["selected_vehicles"]) for r in split_family])
    report_lines.append(f"| {family} | {dc:.3f} | {sc:.3f} | {100*(sc/dc-1):+.3f}% | {dv:.3f} | {sv:.3f} |")

report_lines.extend(
    [
        "",
        "## 结论与协议说明",
        "",
        "- 在同分布固定 CVRPTW100 上，Split 的平均距离和车辆数均高于匹配的 Direct 模型。",
        "- 在 Solomon-100 上，两种方法均对 56 个实例返回可行解；结果采用距离优先选择，车辆数仅单独报告，不能与车辆数优先的官方 SINTEF 口径混用。",
        "- XML100 和 n=200/500/1000 是跨约束评测。原始坐标、需求、容量及目标不变，只补充不激活的中性时间属性。Direct 模型在这些实例上几乎总是立即返回仓库，形成每客户一条路线；因此 Split 明显更好，但这一结果反映的是 CVRPTW Direct 策略向无时间窗 CVRP 的接口迁移失败，不能与原生 AM-CVRP 结果混为同一协议。",
        "- 所有评测成功率均为 100%，没有失败实例。",
    ]
)

summary_path = RESULTS / "am_tw_n100_comparison_summary.csv"
with summary_path.open("w", newline="", encoding="utf-8") as handle:
    writer = csv.DictWriter(handle, fieldnames=list(summary_rows[0]))
    writer.writeheader()
    writer.writerows(summary_rows)

(RESULTS / "AM_SPLIT_CVRPTW100_FINAL_REPORT.md").write_text("\n".join(report_lines) + "\n", encoding="utf-8")
validation = {
    "status": "ok",
    "fixed_cvrptw100_rows": 20_000,
    "solomon100_rows": 112,
    "xml100_rows": 20_000,
    "generalization_rows": 6_000,
    "total_result_rows": 46_112,
    "route_files_checked": 46_112,
    "all_status_ok": True,
}
(RESULTS / "final_validation.json").write_text(json.dumps(validation, indent=2) + "\n", encoding="utf-8")
print(json.dumps(validation, sort_keys=True))
