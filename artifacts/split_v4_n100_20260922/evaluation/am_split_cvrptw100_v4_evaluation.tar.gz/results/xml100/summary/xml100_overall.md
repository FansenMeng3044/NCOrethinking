# XML100 overall results

Success is reported before conditional quality metrics.

| Model | Architecture | Aug success | Aug mean Gap % | Aug P95 Gap % | No-aug success | No-aug mean Gap % | Mean vehicles | Inference s/instance | Postprocess s/instance |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| am_tw_direct_n100 | am_tw | 10000/10000 | 700.8650 | 1464.4717 | 10000/10000 | 700.8650 | 100.000 | 0.005481 | 0.001114 |
| am_tw_split_v4_n100 | am_split_tw | 10000/10000 | 281.9659 | 540.2306 | 10000/10000 | 281.9659 | 14.459 | 0.001887 | 0.003823 |
