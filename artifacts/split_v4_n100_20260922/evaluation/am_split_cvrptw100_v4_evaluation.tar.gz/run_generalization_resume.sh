#!/usr/bin/env bash
set -Eeuo pipefail

B=/root/autodl-tmp/am_tw_split_v4_n100_eval_20260922
BASE=/root/autodl-tmp/split_v4_n100_eval_20260922
REPO=/root/autodl-tmp/NCOrethinking_directctx_nomask_v4_20260921
PY=/root/miniconda3/bin/python
DIRECT="$B/models/am_tw_direct_n100/epoch-100.pt"
SPLIT=/root/autodl-tmp/am_tw_split_n100_directctx_nomask_v4_20260921/outputs/am_split_tw_100/am_tw_split_n100_directctx_nomask_v4_20260921T173646/epoch-100.pt

mkdir -p "$B"/{logs,status,pids,results/generalization}
echo generalization_running > "$B/status/phase"
date -u +%FT%TZ > "$B/status/generalization_resume.started_at_utc"

finish() {
  rc=$?
  printf '%s\n' "$rc" > "$B/status/generalization_resume.exit_code"
  date -u +%FT%TZ > "$B/status/generalization_resume.finished_at_utc"
  if [[ "$rc" -eq 0 ]]; then
    echo evaluation_completed > "$B/status/phase"
    printf '0\n' > "$B/status/crossconstraint_all.exit_code"
  else
    echo generalization_failed > "$B/status/phase"
  fi
}
trap finish EXIT

run_stage() {
  name=$1
  shift
  echo "[$(date -u +%FT%TZ)] START $name"
  "$@"
  rc=$?
  printf '%s\n' "$rc" > "$B/status/${name}.exit_code"
  echo "[$(date -u +%FT%TZ)] END $name exit=$rc"
  return "$rc"
}

for size in 200 500 1000; do
  batch=32
  [[ "$size" == 500 ]] && batch=8
  [[ "$size" == 1000 ]] && batch=2

  run_stage "generalization_direct_n${size}" \
    "$PY" "$B/evaluate_size_generalization_am_tw.py" \
    --repo "$REPO" \
    --dataset "$BASE/data/generalization/cvrp${size}_n1000_seed1234_cap50.pt" \
    --checkpoint "$DIRECT" --architecture am_tw \
    --output "$B/results/generalization/am_tw_direct_n100_to_n${size}" \
    --device cuda:0 --batch-size "$batch" --seed 1234

  run_stage "generalization_split_n${size}" \
    "$PY" "$B/evaluate_size_generalization_am_tw.py" \
    --repo "$REPO" \
    --dataset "$BASE/data/generalization/cvrp${size}_n1000_seed1234_cap50.pt" \
    --checkpoint "$SPLIT" --architecture am_split_tw \
    --output "$B/results/generalization/am_tw_split_v4_n100_to_n${size}" \
    --device cuda:0 --batch-size "$batch" --seed 1234
done
