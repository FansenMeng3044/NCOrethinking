#!/usr/bin/env python3
"""Evaluate AM Direct or AM Split on the frozen CVRPTW100 test set.

The protocol is deterministic greedy decoding with optional 8-fold geometric
augmentation.  Every selected route set is replayed independently with the
shared hard-capacity/hard-time-window reference implementation.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import sys
import time
from pathlib import Path

import torch


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        while chunk := handle.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def augment_xy_by_8(xy: torch.Tensor) -> torch.Tensor:
    x, y = xy[..., [0]], xy[..., [1]]
    return torch.cat(
        (
            torch.cat((x, y), -1),
            torch.cat((1 - x, y), -1),
            torch.cat((x, 1 - y), -1),
            torch.cat((1 - x, 1 - y), -1),
            torch.cat((y, x), -1),
            torch.cat((1 - y, x), -1),
            torch.cat((y, 1 - x), -1),
            torch.cat((1 - y, 1 - x), -1),
        ),
        0,
    )


def augment_batch(batch: dict[str, torch.Tensor], factor: int) -> dict[str, torch.Tensor]:
    if factor == 1:
        return batch
    if factor != 8:
        raise ValueError("augmentation must be 1 or 8")
    result = {
        "depot": augment_xy_by_8(batch["depot"][:, None])[:, 0],
        "loc": augment_xy_by_8(batch["loc"]),
    }
    for key, value in batch.items():
        if key not in result:
            result[key] = value.repeat((factor,) + (1,) * (value.dim() - 1))
    return result


def actions_to_routes(actions: torch.Tensor, customer_count: int) -> list[list[int]]:
    routes: list[list[int]] = []
    route: list[int] = []
    for raw in actions.detach().cpu().tolist():
        value = int(raw)
        if value == 0:
            if route:
                routes.append(route)
                route = []
        elif 1 <= value <= customer_count:
            route.append(value)
        else:
            raise ValueError(f"out-of-range decoder action {value}")
    if route:
        routes.append(route)
    flat = [customer for current in routes for customer in current]
    if sorted(flat) != list(range(1, customer_count + 1)):
        raise ValueError("selected route set fails customer coverage/duplicate check")
    return routes


def atomic_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(payload, indent=2, allow_nan=False), encoding="utf-8")
    temporary.replace(path)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, required=True)
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--dataset", type=Path, required=True)
    parser.add_argument("--architecture", choices=("am_tw", "am_split_tw"), required=True)
    parser.add_argument("--instances", type=int, default=10_000)
    parser.add_argument("--batch-size", type=int, default=32)
    parser.add_argument("--augmentation", type=int, choices=(1, 8), default=8)
    parser.add_argument("--device", default="cuda:0")
    parser.add_argument("--seed", type=int, default=1234)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    torch.manual_seed(args.seed)
    device = torch.device(args.device)
    cvrp = args.repo.resolve() / "NEW_py_ver" / "CVRP"
    am_root = cvrp / "AM_SPLIT"
    for root in (am_root, cvrp, cvrp.parent):
        if str(root) not in sys.path:
            sys.path.insert(0, str(root))

    from CVRPTWCore import (
        replay_cvrptw_actions,
        split_routes_to_actions,
        tensors_from_dict,
    )
    from nets.attention_model import set_decode_type
    from utils.functions import load_model

    raw = torch.load(args.dataset, map_location="cpu", weights_only=False)
    depot, loc, demand, service, tw_start, tw_end = tensors_from_dict(raw, device="cpu")
    total = min(args.instances, loc.size(0))
    if total != args.instances:
        raise ValueError(f"expected {args.instances} instances, found {loc.size(0)}")

    model, model_args = load_model(str(args.checkpoint.resolve()))
    expected = "cvrptw" if args.architecture == "am_tw" else "am_split_tw"
    if model.problem.NAME != expected:
        raise ValueError(f"expected checkpoint problem {expected}, got {model.problem.NAME}")
    if int(model_args["graph_size"]) != 100:
        raise ValueError("formal checkpoint must have training graph_size=100")
    configure = {
        "capacity": float(raw.get("capacity", 1.0)),
        "depot_start": float(raw.get("depot_start", 0.0)),
        "depot_end": float(raw.get("depot_end", 3.0)),
        "speed": float(raw.get("speed", 1.0)),
        "service_duration": float(raw.get("service_duration", 0.2)),
    }
    if args.architecture == "am_split_tw":
        configure["train_reward"] = "split"
    model.problem.configure(**configure)
    model.to(device).eval()
    set_decode_type(model, "greedy")

    args.output.mkdir(parents=True, exist_ok=True)
    route_root = args.output / "routes"
    route_root.mkdir(parents=True, exist_ok=True)
    rows: list[dict] = []
    started = time.perf_counter()

    with torch.inference_mode():
        for start in range(0, total, args.batch_size):
            stop = min(total, start + args.batch_size)
            batch_size = stop - start
            base = {
                "depot": depot[start:stop, 0].to(device),
                "loc": loc[start:stop].to(device),
                "demand": demand[start:stop].to(device),
                "service_time": service[start:stop].to(device),
                "tw_start": tw_start[start:stop].to(device),
                "tw_end": tw_end[start:stop].to(device),
                "depot_start": torch.full((batch_size,), configure["depot_start"], device=device),
                "depot_end": torch.full((batch_size,), configure["depot_end"], device=device),
                "speed": torch.full((batch_size,), configure["speed"], device=device),
            }
            batch = augment_batch(base, args.augmentation)
            embeddings, _ = model.embedder(model._init_embed(batch))
            _, tours = model._inner(batch, embeddings)

            if args.architecture == "am_split_tw":
                split = model.problem.split_costs(batch, tours, return_predecessors=True)
                actions = split_routes_to_actions(tours, split.predecessors)
            else:
                actions = tours

            replay = replay_cvrptw_actions(
                batch["depot"][:, None],
                batch["loc"],
                batch["demand"],
                batch["service_time"],
                batch["tw_start"],
                batch["tw_end"],
                actions,
                capacity=configure["capacity"],
                depot_start=batch["depot_start"],
                depot_end=batch["depot_end"],
                speed=configure["speed"],
            )
            if not replay.feasible.all():
                raise AssertionError("independent CVRPTW replay rejected a decoded candidate")
            cost_matrix = replay.distances.reshape(args.augmentation, batch_size)
            vehicle_matrix = replay.route_counts.reshape(args.augmentation, batch_size)
            best_cost, best_aug = cost_matrix.min(dim=0)
            for offset in range(batch_size):
                global_index = start + offset
                augmentation_index = int(best_aug[offset].item())
                candidate = augmentation_index * batch_size + offset
                routes = actions_to_routes(actions[candidate], loc.size(1))
                cost = float(best_cost[offset].item())
                vehicles = int(vehicle_matrix[augmentation_index, offset].item())
                if vehicles != len(routes):
                    raise AssertionError("route count mismatch after replay")
                route_path = route_root / f"{global_index:05d}.json"
                atomic_json(
                    route_path,
                    {
                        "instance": global_index,
                        "architecture": args.architecture,
                        "status": "ok",
                        "distance": cost,
                        "vehicles": vehicles,
                        "augmentation_index": augmentation_index,
                        "routes": routes,
                    },
                )
                rows.append(
                    {
                        "instance": global_index,
                        "status": "ok",
                        "distance": cost,
                        "vehicles": vehicles,
                        "augmentation_index": augmentation_index,
                        "routes_json": route_path.relative_to(args.output).as_posix(),
                    }
                )
            if stop % 500 == 0 or stop == total:
                print(f"completed={stop}/{total}", flush=True)

    csv_path = args.output / "results.csv"
    with csv_path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    distances = torch.tensor([row["distance"] for row in rows], dtype=torch.double)
    vehicles = torch.tensor([row["vehicles"] for row in rows], dtype=torch.double)
    elapsed = time.perf_counter() - started
    summary = {
        "protocol": "fixed_cvrptw100_greedy_8fold_strict_replay_v1",
        "architecture": args.architecture,
        "instances": len(rows),
        "success": len(rows),
        "mean_distance": distances.mean().item(),
        "standard_error": distances.std(unbiased=True).item() / math.sqrt(len(rows)),
        "mean_vehicles": vehicles.mean().item(),
        "elapsed_seconds": elapsed,
        "mean_inference_seconds": elapsed / len(rows),
        "dataset": str(args.dataset.resolve()),
        "dataset_sha256": sha256_file(args.dataset),
        "checkpoint": str(args.checkpoint.resolve()),
        "checkpoint_sha256": sha256_file(args.checkpoint),
        "checkpoint_epoch": 100,
        "decoding": "greedy",
        "augmentation": args.augmentation,
        "verification": "independent strict replay: coverage, duplicates, capacity, customer time windows, depot return, and distance",
    }
    atomic_json(args.output / "summary.json", summary)
    print(json.dumps(summary, indent=2, allow_nan=False), flush=True)


if __name__ == "__main__":
    main()
