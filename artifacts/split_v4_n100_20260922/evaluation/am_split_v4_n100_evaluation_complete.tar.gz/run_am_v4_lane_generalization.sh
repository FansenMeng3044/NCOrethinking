#!/usr/bin/env bash
set -u -o pipefail

B=/root/autodl-tmp/am_split_v4_n100_eval_20260922
BASE=/root/autodl-tmp/split_v4_n100_eval_20260922
REPO=/root/autodl-tmp/NCOrethinking_directctx_nomask_v4_20260921
PY=/root/miniconda3/bin/python
SPLIT_CKPT=/root/autodl-tmp/am_split_n100_directctx_nomask_v4_20260921/outputs/am_split_100/am_split_n100_directctx_nomask_v4_split_20260921T173647/epoch-100.pt
DIRECT_CKPT="$B/models/am_direct/epoch-100.pt"

run_stage() {
  local name=$1
  shift
  echo "$(date --iso-8601=seconds) START $name"
  "$@"
  local code=$?
  printf '%s\n' "$code" >"$B/status/${name}.exit_code"
  echo "$(date --iso-8601=seconds) END $name exit=$code"
  return "$code"
}

for size in 200 500 1000; do
  batch=32
  [[ "$size" == 500 ]] && batch=8
  [[ "$size" == 1000 ]] && batch=2

  run_stage "generalization_split_n${size}" \
    "$PY" "$B/scripts/evaluate_size_generalization_am_v4.py" \
    --repo "$REPO" \
    --dataset "$BASE/data/generalization/cvrp${size}_n1000_seed1234_cap50.pt" \
    --checkpoint "$SPLIT_CKPT" --architecture am_split \
    --output "$B/results/generalization/am_split_v4_n100_to_n${size}" \
    --device cuda:1 --batch-size "$batch" --seed 1234 || exit $?

  run_stage "generalization_direct_n${size}" \
    "$PY" "$B/scripts/evaluate_size_generalization_am_v4.py" \
    --repo "$REPO" \
    --dataset "$BASE/data/generalization/cvrp${size}_n1000_seed1234_cap50.pt" \
    --checkpoint "$DIRECT_CKPT" --architecture am \
    --output "$B/results/generalization/am_direct_n100_to_n${size}" \
    --device cuda:1 --batch-size "$batch" --seed 1234 || exit $?
done

printf '0\n' >"$B/status/lane_generalization.exit_code"
date --iso-8601=seconds >"$B/status/lane_generalization.completed_at"
