#!/usr/bin/env bash
set -u -o pipefail

B=/root/autodl-tmp/am_split_v4_n100_eval_20260922
BASE=/root/autodl-tmp/split_v4_n100_eval_20260922
REPO=/root/autodl-tmp/NCOrethinking_directctx_nomask_v4_20260921
PY=/root/miniconda3/bin/python
SPLIT_CKPT=/root/autodl-tmp/am_split_n100_directctx_nomask_v4_20260921/outputs/am_split_100/am_split_n100_directctx_nomask_v4_split_20260921T173647/epoch-100.pt
DIRECT_CKPT="$B/models/am_direct/epoch-100.pt"

run_stage() {
  local name=$1
  shift
  echo "$(date --iso-8601=seconds) START $name"
  "$@"
  local code=$?
  printf '%s\n' "$code" >"$B/status/${name}.exit_code"
  echo "$(date --iso-8601=seconds) END $name exit=$code"
  return "$code"
}

run_stage fixed_cvrp100_direct \
  "$PY" "$B/scripts/evaluate_fixed_cvrp_am.py" \
  --repo "$REPO" --checkpoint "$DIRECT_CKPT" \
  --dataset "$BASE/data/fixed/cvrp100_n10000_seed1234.pt" \
  --architecture am --training-size 100 --instances 10000 --batch-size 64 \
  --augmentation 8 --device cuda:0 --seed 1234 \
  --output "$B/results/fixed_cvrp100/am_direct_n100.json" \
  --per-instance-output "$B/results/fixed_cvrp100/am_direct_n100.csv" || exit $?

run_stage fixed_cvrp100_split_v4 \
  "$PY" "$B/scripts/evaluate_fixed_cvrp_am.py" \
  --repo "$REPO" --checkpoint "$SPLIT_CKPT" \
  --dataset "$BASE/data/fixed/cvrp100_n10000_seed1234.pt" \
  --architecture am_split --training-size 100 --instances 10000 --batch-size 64 \
  --augmentation 8 --device cuda:0 --seed 1234 \
  --output "$B/results/fixed_cvrp100/am_split_v4_n100.json" \
  --per-instance-output "$B/results/fixed_cvrp100/am_split_v4_n100.csv" || exit $?

run_stage xml100 \
  "$PY" "$BASE/scripts/xml100/evaluate_xml100.py" \
  --repo "$REPO" --models "$B/models_xml100.json" \
  --data-root "$BASE/data/xml100" \
  --dataset-manifest "$BASE/scripts/xml100/xml100_dataset_manifest.json" \
  --optimal-costs "$BASE/scripts/xml100/xml100_optimal_costs.csv" \
  --output "$B/results/xml100" --device cuda:0 --augmentation 8 --seed 1234 \
  --batch-size-pomo 16 --batch-size-am 64 --require-checkpoint-hashes || exit $?

run_stage xml100_verify \
  "$PY" "$BASE/scripts/xml100/verify_xml100_results.py" \
  --results "$B/results/xml100/xml100_results.csv" \
  --models "$B/models_xml100.json" \
  --data-root "$BASE/data/xml100" \
  --dataset-manifest "$BASE/scripts/xml100/xml100_dataset_manifest.json" \
  --optimal-costs "$BASE/scripts/xml100/xml100_optimal_costs.csv" \
  --report "$B/results/xml100/verification_report.json" || exit $?

run_stage xml100_summarize \
  "$PY" "$BASE/scripts/xml100/summarize_xml100.py" \
  --results "$B/results/xml100/xml100_results.csv" \
  --output-dir "$B/results/xml100/summary" || exit $?

printf '0\n' >"$B/status/lane_fixed_xml.exit_code"
date --iso-8601=seconds >"$B/status/lane_fixed_xml.completed_at"
