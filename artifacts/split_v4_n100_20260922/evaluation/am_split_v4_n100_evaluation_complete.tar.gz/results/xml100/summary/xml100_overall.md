# XML100 overall results

Success is reported before conditional quality metrics.

| Model | Architecture | Aug success | Aug mean Gap % | Aug P95 Gap % | No-aug success | No-aug mean Gap % | Mean vehicles | Inference s/instance | Postprocess s/instance |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| am_direct_n100 | am | 10000/10000 | 8.7273 | 17.8636 | 10000/10000 | 15.0735 | 12.707 | 0.002900 | 0.000802 |
| am_split_v4_n100 | am_split | 10000/10000 | 12.0216 | 19.4233 | 10000/10000 | 15.9489 | 12.911 | 0.001967 | 0.003790 |
